//ヘッダーメニュー
new Vue({
  el: '#header_nav',
});

//ログインモーダル
new Vue({
  el: '#login_modal',
});

//フッター
new Vue({
  el: '#footer_menu',
});

const button = document.getElementById('register_btn');

// ボタンをクリックすると、イベントリスナーが実行される
button.addEventListener('click', () => {
  alert('登録が完了しました。登録頂いたメールアドレスにて内容を御確認ください。');
});