//ヘッダー
new Vue({
  el: '#header_nav',
});

//ログインモーダル
new Vue({
  el: '#login_modal',
});

//フッター
new Vue({
  el: '#footer_menu',
});

function check(){
  
  var flag = 0;
  
  if (document.form1.field1.value === "") { // 「メールアドレス」の入力チェック
    flag = 1;
  }
  
  else if (document.form1.field2.value === "") { // 「名前」の入力チェック
    flag = 1;
  }
  
  else if (document.form1.field3.value === "") { // 「内容」の入力チェック
    flag = 1;
    
  }
  // 設定終了
  
  if (flag) {

	  window.alert('未入力の項目があります'); // 入力漏れがあれば警告ダイアログを表示
	  return false; // 送信を中止
	  }
	  
	  else {
	    return true; // 送信を実行
	    }
}
