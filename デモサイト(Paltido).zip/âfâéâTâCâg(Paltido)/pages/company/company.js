//ヘッダー
new Vue({
  el: '#header_nav',
});

//ログインモーダル
new Vue({
  el: '#login_modal',
});

//フッター
new Vue({
  el: '#footer_menu',
});
